$(document).ready(function() {

	$('#cursusLink').on('click', function(e) {
		e.preventDefault();
		$('#headerTitle').html("Cursus");

		console.log("test");

		$.ajax({
			url : 'http://localhost:8080/FormationProjetLeRetour/rest/cursuss',
			data : [],
			type : 'GET',
			cache : false,
			dataType : 'json',
			success : function(data) {
				let html = "";
				let i=0;
				html+=`<table class="table table-bordered">  <thead>
				 <th> Nom </th> 					

			 </thead><tbody id="tbody">
										`
				for (let cursus of data) {
					html += `
						 <tr>
						 <td>${cursus.nom}</td> 
			    	
			    		 <td class="removeCursus">
 			    		   <form>
					 <button type="button" id="removeid${i}" name="remove">Supprimer</button>
						 </form>
		 
 			    		  </td>
			    		  
			    		
			    		  
			    		 </tr>
			    		
			    		 
						
			    		 
			    		 ` 
						
						$(document).on('click',`#removeid${i}`,
							function(e) {
								e.preventDefault();
								console.log("test");

								$.ajax({
									url : `http://localhost:8080/FormationProjetLeRetour/rest/cursuss/${cursus.id}/delete`,
									data : [],
									type : 'DELETE',
									cache : false,
									dataType : 'text',
									success : function(data) {
										 $('#cursusLink').trigger('click');
									
							
						}
								}
								
								);
								}
						
				);
						i++;
				}
				
				html+=` </tbody>
			    		 </table>
			    		`
				$('#list').html(html);
				$('#btnAddDiv').html(`<button type="button" id=btnAddCursus> Ajouter Cursus </button>`);

			


			}
		});

	}
	);
	
	

	class Cursus {
		  constructor( nom  ) {
			  this.nom =  nom; 	  
			  
		  }
		} 
	
	$(document).on('click','#btnAddReelCursus', function(e) {
		e.preventDefault();
		let cursus = new Cursus($('#inputCursusnom').val());
		
		$.ajax({
			  headers: { 
			        'Accept': 'application/json',
			        'Content-Type': 'application/json' 
			    },
			url : 'http://localhost:8080/FormationProjetLeRetour/rest/cursuss/add',
			data : JSON.stringify(cursus),
			type : 'POST',
			cache : false,
			dataType : 'json',
			success : function(data) {			
				 $('#cursusLink').trigger('click');

			
			}
		});
		


	});
		

	
	
	$(document).on('click','#btnAddCursus', function(e) {
		
		$('#addForm').html(`<form class="form-inline"
		>
		<div class="form-group">
			<table class="table borderless">
					<tr>
						<td>nom</td>
						<td><input id="inputCursusnom" type="text" name="cursusNom" />
					</tr> 
			</table>

			<button id="btnAddReelCursus" class="form-control" name="add" >Ajouter cursus</button>
		</div>
	</form>`);		


	});


}

);