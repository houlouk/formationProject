$(document).ready(function() {
	let nbElems=0;
	function removeEvents() {
		let j=0;
		while(j<nbElems){
			console.log(j);
		$(document).off('click',`#removeProfesseurid${j}`);
			j++;
		}
	}
	$('#professeurLink').on('click', function(e) {
		e.preventDefault();
		$('#headerTitle').html("Professeur");
		
		removeEvents();
		
		$('#btnAddDiv').empty();
		
		
		console.log("test unbind 10");

		$.ajax({
			url : 'http://localhost:8080/FormationProjetLeRetour/rest/professeurs',
			data : [],
			type : 'GET',
			cache : false,
			dataType : 'json',
			success : function(data) {
				nbElems=data.length;
				let html = "";
				let i=0;
				html+=`<table class="table table-bordered">  <thead>
				 <th> Nom </th>  <th> Prenom </th> 					

			 </thead><tbody id="tbody">
										`
				for (let professeur of data) {
					html += `
						 <tr>
						 <td>${professeur.nom}</td>  <td>${professeur.prenom}</td> 
			    	
			    		 <td class="removeProfesseur">
 			    		   <form>
					 <button type="button" id="removeProfesseurid${i}" name="remove">Supprimer</button>
						 </form>
		 
 			    		  </td>
			    		  
			    		
			    		  
			    		 </tr>
			    		
			    		 
						
			    		 
			    		 ` 
												$(document).on('click',`#removeProfesseurid${i}`,
							function(e) {
								e.preventDefault();
								console.log("test remove 222");

								$.ajax({
									url : `http://localhost:8080/FormationProjetLeRetour/rest/professeurs/${professeur.id}/delete`,
									data : [],
									type : 'DELETE',
									cache : false,
									dataType : 'text',
									success : function(data) {
										$('#professeurLink').trigger('click');
									
							
						}
								}
								
								);
								}
						
				);
						i++;
				}
				
				html+=` </tbody>
			    		 </table>
			    		`
				$('#list').html(html);
				$('#btnAddDiv').html(`<button type="button" id=btnAddProfesseur> Ajouter Professeur </button>`);

			


			}
		});

	}
	);
	
	

	class Professeur {
		  constructor( nom ,  prenom  ) {
			  this.nom =  nom; 
			  this.prenom =  prenom; 	  
			  
		  }
		} 
	
	$(document).on('click','#btnAddReelProfesseur', function(e) {
		e.preventDefault();
		let professeur = new Professeur($('#inputProfesseurnom').val(),$('#inputProfesseurprenom').val());
		
		$.ajax({
			  headers: { 
			        'Accept': 'application/json',
			        'Content-Type': 'application/json' 
			    },
			url : 'http://localhost:8080/FormationProjetLeRetour/rest/professeurs/add',
			data : JSON.stringify(professeur),
			type : 'POST',
			cache : false,
			dataType : 'json',
			success : function(data) {		
				console.log("reload");
				 $('#professeurLink').trigger('click');

			
			}
		});
		


	});
		

	
	
	$(document).on('click','#btnAddProfesseur', function(e) {
		
		$('#addForm').html(`<form class="form-inline"
		>
		<div class="form-group">
			<table class="table borderless">
					<tr>
						<td>nom</td>
						<td><input id="inputProfesseurnom" type="text" name="professeurNom" />
					</tr> 	<td>prenom</td>
						<td><input id="inputProfesseurprenom" type="text" name="professeurPrenom" />
					</tr> 
			</table>

			<button id="btnAddReelProfesseur" class="form-control" name="add" >Ajouter professeur</button>
		</div>
	</form>`);		


	});


}

);